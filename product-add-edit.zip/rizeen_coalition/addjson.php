<?php
    $current_data = file_get_contents('product_data.json');  
    $array_data = json_decode($current_data, true);  
    if(isset($array_data)) {
        $last_item    = end($array_data);
        $last_item_id = $last_item['id'];
    } else {
        $last_item_id = 0;
    }
    $row_total = $_POST["quantity"] * $_POST["price"];
    $extra = array(  
    'id'            =>     ++$last_item_id,
    'name'          =>     $_POST['name'],  
    'quantity'      =>     $_POST["quantity"],  
    'price'         =>     $_POST["price"],
    'mydatetime'    =>     $_POST["mydatetime"], 
    'last_updated'  =>     $_POST["mydatetime"], 
    'row_total'     =>     $row_total 
    );  
    $array_data[] = $extra;  
    $final_data = json_encode($array_data);  
    file_put_contents('product_data.json', $final_data);
?>