<!-- Header -->
<?php include "header.php"?>
<?php
  // checking if the variable is set or not and if set adding the set data value to variable product_id
  if(isset($_GET['product_id']))
  {
    $product_id = $_GET['product_id']; 
  }
  $current_data = file_get_contents('product_data.json');  
  $json_arr = json_decode($current_data, true);  
  foreach ($json_arr as $key => $value) {
    if ($value['id'] == $product_id) {
      $name = $json_arr[$key]['name'];
      $quantity = $json_arr[$key]['quantity'];
      $price = $json_arr[$key]['price'];
    }
  }
  //Processing form data when form is submitted
  if(isset($_POST['update'])) {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $last_updated = gmdate('Y-m-d\TH:i:s');
    $row_total = $_POST['quantity'] * $_POST['price'];            
    foreach ($json_arr as $key => $value) {
      if ($value['id'] == $product_id) {
        $json_arr[$key]['name'] = $name;
        $json_arr[$key]['quantity'] = $quantity;
        $json_arr[$key]['price'] = $price;
        $json_arr[$key]['last_updated'] = $last_updated;
        $json_arr[$key]['row_total'] = $row_total;
      }
    }    
    $final_data = json_encode($json_arr);  
    file_put_contents('product_data.json', $final_data);
    echo "<script type='text/javascript'>alert('Product data updated successfully!')</script>";
  }             
?>
<!-- BACK button to go to the home page -->
<div class="container">
  <a href="index.php" class="btn btn-warning mt-1"> <b> <i class="bi bi-arrow-left-circle-fill"></i> Back </b> </a>
<div>

<h3 class="text-center">UPDATE PRODUCT DETAILS</h3>
  <div>
    <form method="post">
      <div class="form-group">
        <label for="name">PRODUCT NAME</label>
        <input type="text" name="name" class="form-control mb-3 mt-1" value="<?php echo $name  ?>" required>
      </div>
      <div class="form-group">
        <label for="quantity">QUANTITY IN STOCK</label>
        <input type="number" name="quantity" class="form-control mb-3 mt-1" value="<?php echo $quantity  ?>" required>
      </div>
      <div class="form-group">
        <label for="price">PRICE PER ITEM</label>
        <input type="number" name="price" step="0.01" class="form-control mb-3 mt-1" value="<?php echo $price  ?>" required>
      </div>
      <div class="form-group d-flex justify-content-center">
         <input type="submit"  name="update" class="btn btn-primary mt-2" value="UPDATE">
      </div>
    </form>    
  </div>
</body>  
</html>  