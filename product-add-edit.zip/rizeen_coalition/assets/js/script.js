jQuery(document).ready(function ($) {
    $('form.myajax').submit(function (e) {
        e.preventDefault();
        var myajaxForm = $(this),
        formData = {
            name: $(this).find(".name").val(),
            quantity: $(this).find(".quantity").val(),
            price: $(this).find(".price").val(),
            mydatetime: $(this).find(".mydatetime").val(),
            last_updated: $(this).find(".mydatetime").val()
        };
        $.ajax({
            data: formData,
            type: 'post',
            url: 'addjson.php',
            success: function () {
                $("#mydiv").load(location.href + " #mydiv");
                    
            },
            error: function (data) {
            }
        })
    });
});
