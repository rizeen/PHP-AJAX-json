<?php include "header.php"?>
<div class="container">  
  <h3 class="my-3">ADD A NEW PRODUCT</h3>               
  <form class="myajax">  
    <label>PRODUCT NAME</label>  
    <input type="text" name="name" class="form-control mb-3 mt-1 name" required />
    <label>QUANTITY IN STOCK</label>  
    <input type="number" name="quantity" class="form-control mb-3 mt-1 quantity" required />
    <label>PRICE PER ITEM</label>  
    <input type="number" name="price" step="0.01" class="form-control mb-3 mt-1 price" required />
    <input type="hidden" name="mydatetime" class="form-control mydatetime" value="<?php echo gmdate('Y-m-d\TH:i:s'); ?>" required />
    <input type="submit" name="submit" value="+ ADD" class="btn btn-danger mb-5" /> 
    <?php  
      $current_data = file_get_contents('product_data.json');  
      $array_data = json_decode($current_data, true);  
      $message = $array_data;
    ?>
    <div class="message table-responsive mb-5" id="mydiv">                 
      <table class="table">
        <thead>
          <tr class="text-uppercase">
            <th >Product Name</th>
            <th >Qty in stock</th>
            <th >Price per item</th>
            <th >DateTime Added (UTC)</th>
            <th >Last Updated (UTC)</th>
            <th class="text-end" >Total</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $final_total = 0;
        if(isset($message)) {  
          foreach($message as $arr) {
            $final_total = $final_total + $arr["row_total"];
            $row_id = $arr['id'];                
        ?>
            <tr>
            <td ><?php echo $arr["name"] ?></td>
            <td ><?php echo $arr["quantity"] ?></td>
            <td ><?php echo $arr["price"] ?></td>
            <td ><?php echo $arr["mydatetime"] ?></td>
            <td ><?php echo $arr["last_updated"] ?></td>
            <td class="text-end" ><?php echo $arr["row_total"] ?></td>
            <td ><a href='update.php?edit&product_id=<?php echo $row_id ?>' class='btn btn-primary'><i class='bi bi-pencil'></i> EDIT</a></td>
          </tr>
          <?php
          }
        }
          ?>
          <tr class="last_row">
          <td colspan="5" class="text-end fw-bold border-0">TOTAL SUM:</td>
          <td class="text-end border-0"><?php echo $final_total ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </form>  
</div>  
</body>  
</html>  